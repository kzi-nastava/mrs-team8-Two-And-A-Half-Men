package CordinatesPacage;

import Metrics.MetricsDistance;
import Utils.Constance;

public abstract class Cordinates {
    protected double latitude;
    protected double longitude;

     Cordinates(){}
     Cordinates(double latitude, double longitude){
        this.latitude = latitude;
        this.longitude = longitude;
    }
    Cordinates(String address){
        setCordinate(address);
    }
    public double getLongitude() {
        return longitude;
    }

    public double getLatitude() {
        return latitude;
    }
    public abstract void setCordinate(String address);
    public void setCordinate(double latitude, double longitude)
    {
        this.latitude = latitude;
        this.longitude = longitude;
    }
    public abstract String getAddress();
    public double distanceAirLine(Cordinates other ) {
        double latDistance = Math.toRadians(other.latitude - this.latitude);
        double lonDistance = Math.toRadians(other.longitude - this.longitude);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(this.latitude)) * Math.cos(Math.toRadians(other.latitude))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return Constance.EARTH_RADIUS_M * c;
    }
    public double distanceAirLine(Cordinates other, MetricsDistance metric ) {
        double latDistance = Math.toRadians(other.latitude - this.latitude);
        double lonDistance = Math.toRadians(other.longitude - this.longitude);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(this.latitude)) * Math.cos(Math.toRadians(other.latitude))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return metric.fromMeters(Constance.EARTH_RADIUS_M * c);
    }
    public abstract double GetTimeMap(Cordinates other);
    public abstract double GetDistanceMap(Cordinates other);
    public abstract double[] GetRouteMap(Cordinates other);
}
