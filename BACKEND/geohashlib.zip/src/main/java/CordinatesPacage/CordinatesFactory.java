package CordinatesPacage;

public abstract class CordinatesFactory {
public abstract Cordinates getCordinate(String address);
public abstract Cordinates getCordinate(double latitude, double longitude);
}
