package CordinatesPacage;

public class OpenStreatCordinatesFactory extends CordinatesFactory {


    public OpenStreatCordinatesFactory() {
    }

    @Override
    public Cordinates getCordinate(String address) {
        return new OpenStreatCordinates(address);
    }

    @Override
    public Cordinates getCordinate(double latitude, double longitude) {
        return new OpenStreatCordinates(latitude, longitude);
    }
}
