package Locations;

import java.util.ArrayList;
import java.util.concurrent.Callable;

import CordinatesPacage.Cordinates;
import CordinatesPacage.CordinatesFactory;
import Metrics.MetricsDistance;
import Metrics.MetricsTime;

public abstract class LocationTransformer {

    LocationTransformer(CordinatesFactory factory) {

        this.factory = factory;
    }

    protected CordinatesFactory factory;
    public abstract String transformLocation(ArrayList<Cordinates> locations);
    public String transformAdress(ArrayList<String> address) {
        StringBuilder hashBuilder = new StringBuilder();
        ArrayList<Cordinates> locations = new ArrayList<>();
        for (String adress : address) {
            locations.add(factory.getCordinate(adress));
        }
        return transformLocation(locations);
    }
    public String transformFromPoints(ArrayList<double[]> points) {
        StringBuilder hashBuilder = new StringBuilder();
        ArrayList<Cordinates> locations = new ArrayList<>();
        for (double[] point : points) {
            locations.add(factory.getCordinate(point[0], point[1]));
        }
        return transformLocation(locations);
    }




    public abstract ArrayList<Cordinates> transformToCordinnates(String hash);
    public ArrayList<String> transformToAdress(String hash) {
        ArrayList<Cordinates> cords = transformToCordinnates(hash);
        ArrayList<String> adress = new ArrayList<>();
        for (Cordinates cordinate : cords) {
            adress.add(cordinate.getAddress());
        }
        return adress;

    }


    //Returns in meters
    public double calculateDistanceAir(String hash) {
        ArrayList<Cordinates> cords = transformToCordinnates(hash);
        double distance = 0.0;
        Cordinates previusCordinate = null;
        for (Cordinates cordinate : cords) {
            if (previusCordinate != null) {
                distance += cordinate.distanceAirLine(previusCordinate);
            }
            previusCordinate = cordinate;
        }
        return distance;
    }
    public double calculateDistanceAir(ArrayList<String> hashCodes) {
        double distance = 0.0;
       for( String hash : hashCodes) {
           ArrayList<Cordinates> cords = transformToCordinnates(hash);
           Cordinates previusCordinate = null;
           for (Cordinates cordinate : cords) {
               if (previusCordinate != null) {
                   distance += cordinate.distanceAirLine(previusCordinate);
               }
               previusCordinate = cordinate;
           }
       }
        return distance;
    }
    //Returns in specified metric
    public double calculateDistance(String hash, MetricsDistance metric) {
        return metric.fromMeters(calculateDistanceAir(hash));
    }
    public double calculateDistance(ArrayList<String> hashCodes, MetricsDistance metric) {
        return metric.fromMeters(calculateDistanceAir(hashCodes));
    }
    //Returns in meters
    public double calculateDistanceMap(String hash) {
        ArrayList<Cordinates> cords = transformToCordinnates(hash);
        double distance = 0.0;
        Cordinates previusCordinate = null;
        for (Cordinates cordinate : cords) {
            if (previusCordinate != null) {
                distance += previusCordinate.GetDistanceMap(cordinate);
            }
            previusCordinate = cordinate;
        }
        return distance;
    }
    public double calculateDistanceMap(ArrayList<String> hashCodes) {
        double distance = 0.0;
        for (String hash : hashCodes) {
            ArrayList<Cordinates> cords = transformToCordinnates(hash);
            Cordinates previusCordinate = null;
            for (Cordinates cordinate : cords) {
                if (previusCordinate != null) {
                    distance += cordinate.GetDistanceMap(previusCordinate);
                }
                previusCordinate = cordinate;
            }
        }
        return distance;
    }
    //Returns in specified metric
    public double calculateDistanceMap(String hash, MetricsDistance metric) {
        return metric.fromMeters(calculateDistanceMap(hash));
    }
    public double calculateDistanceMap(ArrayList<String> hashCodes, MetricsDistance metric) {
        return metric.fromMeters(calculateDistanceMap(hashCodes));
    }
    public double calculateTimeMap(String hash) {
        ArrayList<Cordinates> cords = transformToCordinnates(hash);
        double time = 0.0;
        Cordinates previusCordinate = null;
        for (Cordinates cordinate : cords) {
            if (previusCordinate != null) {
                time += previusCordinate.GetTimeMap(cordinate);
            }
            previusCordinate = cordinate;
        }
        return time;
    }
    public double calculateTimeMap(ArrayList<String> hashCodes) {
        double time = 0.0;
        for (String hash : hashCodes) {
            ArrayList<Cordinates> cords = transformToCordinnates(hash);
            Cordinates previusCordinate = null;
            for (Cordinates cordinate : cords) {
                if (previusCordinate != null) {
                    time += cordinate.GetTimeMap(previusCordinate);
                }
                previusCordinate = cordinate;
            }
        }
        return time;
    }
    public double calculateTimeMap(String hash, MetricsTime metric) {
        return metric.fromSeconds(calculateTimeMap(hash));
    }
    public double calculateTimeMap(ArrayList<String> hashCodes, MetricsTime metric) {
        return metric.fromSeconds(calculateTimeMap(hashCodes));
    }
    public double[] calculateRouteMap(String hash) {
        ArrayList<Cordinates> cords = transformToCordinnates(hash);
        double totalDistance = 0.0;
        double totalTime = 0.0;
        Cordinates previusCordinate = null;
        for (Cordinates cordinate : cords) {
            if (previusCordinate != null) {
                totalDistance += previusCordinate.GetDistanceMap(cordinate);
                totalTime += previusCordinate.GetTimeMap(cordinate);
            }
            previusCordinate = cordinate;
        }
        return new double[] { totalDistance, totalTime };
    }
    public double[] calculateRouteMap(ArrayList<String> hashCodes) {
        double totalDistance = 0.0;
        double totalTime = 0.0;
        for (String hash : hashCodes) {
            ArrayList<Cordinates> cords = transformToCordinnates(hash);
            Cordinates previusCordinate = null;
            for (Cordinates cordinate : cords) {
                if (previusCordinate != null) {
                    totalDistance += cordinate.GetDistanceMap(previusCordinate);
                    totalTime += cordinate.GetTimeMap(previusCordinate);
                }
                previusCordinate = cordinate;
            }
        }
        return new double[] { totalDistance, totalTime };
    }
    public double[] calculateRouteMap(String hash, MetricsDistance distanceMetric, MetricsTime timeMetric) {
        double[] route = calculateRouteMap(hash);
        return new double[] { distanceMetric.fromMeters(route[0]), timeMetric.fromSeconds(route[1]) };
    }
    public double[] calculateRouteMap(ArrayList<String> hashCodes, MetricsDistance distanceMetric, MetricsTime timeMetric) {
        double[] route = calculateRouteMap(hashCodes);
        return new double[] { distanceMetric.fromMeters(route[0]), timeMetric.fromSeconds(route[1]) };
    }

   }


