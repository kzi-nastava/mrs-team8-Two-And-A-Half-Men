package Locations;

import CordinatesPacage.Cordinates;
import CordinatesPacage.CordinatesFactory;
import ch.hsr.geohash.GeoHash;

import java.util.ArrayList;

public class LocationTransformerGeoHash extends LocationTransformer {

    public int lenght;
    public LocationTransformerGeoHash(CordinatesFactory factory, int lenght) {
        super(factory);
        this.lenght = lenght;
    }

    @Override
    public String transformLocation(ArrayList<Cordinates> locations) {
        StringBuilder hahsBuilder = new StringBuilder();
        for (Cordinates location : locations) {
            System.out.println(location.getLatitude());
            GeoHash geoHash = GeoHash.withCharacterPrecision(location.getLatitude(), location.getLongitude(), this.lenght);
            String hash = geoHash.toBase32();
            hahsBuilder.append(hash);
        }
        return hahsBuilder.toString() ;
    }

    @Override
    public ArrayList<Cordinates> transformToCordinnates(String hash) {
        ArrayList<Cordinates> cordinates = new ArrayList<>();
        for (int i = 0; i < hash.length(); i += this.lenght) {
            String base = hash.substring(i, i + this.lenght);
            System.out.println(base);
            try {
                GeoHash geoHash = GeoHash.fromGeohashString(base);
                cordinates.add(factory.getCordinate(geoHash.getOriginatingPoint().getLatitude(), geoHash.getOriginatingPoint().getLongitude()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return cordinates;
    }

}
