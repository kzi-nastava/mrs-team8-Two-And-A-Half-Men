package Locations;

import CordinatesPacage.Cordinates;
import CordinatesPacage.CordinatesFactory;
import ch.hsr.geohash.GeoHash;

import java.util.ArrayList;

public class LocationTransformerGeoHashCompressed extends LocationTransformer {

    private int lenght;
    public LocationTransformerGeoHashCompressed(CordinatesFactory factory, int lenght) {
        super( factory);
        this.lenght = lenght;
    }


    @Override
    public String transformLocation(ArrayList<Cordinates> locations) {
        StringBuilder hahsBuilder = new StringBuilder();
        String startingHash = null;
        boolean isFirst = true;
        for (Cordinates location : locations) {
            //System.out.println(location.getLatitude());
            GeoHash geoHash = GeoHash.withCharacterPrecision(location.getLatitude(), location.getLongitude(), this.lenght);
            String hash = geoHash.toBase32();
            if (isFirst) {
                startingHash = hash;
                isFirst = false;
            } else {
                int commonPrefixLenght = 0;
                for (int i = 0; i < this.lenght; i++) {
                    if (startingHash.charAt(i) == hash.charAt(i)) {
                        commonPrefixLenght++;
                    } else {
                        break;
                    }
                }
                if (commonPrefixLenght > 1) {
                    hahsBuilder.append("|");
                    hahsBuilder.append(commonPrefixLenght);
                    hash = hash.substring(commonPrefixLenght);
                }
            }
            hahsBuilder.append(hash);
        }
        return hahsBuilder.toString();
    }

    @Override
    public ArrayList<Cordinates> transformToCordinnates(String hash) {
        ArrayList<Cordinates> cordinates = new ArrayList<>();
        int index = 0;
        String startingHash = hash.substring(0, this.lenght);
        try { //Find a way how this could work faster
            GeoHash geoHash = GeoHash.fromGeohashString(startingHash);
             cordinates.add(factory.getCordinate(geoHash.getOriginatingPoint().getLatitude(), geoHash.getOriginatingPoint().getLongitude()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        index += this.lenght;
        while (index < hash.length()){
            int commonPrefixLenght = 0;
            char isCommpressed = hash.charAt(index);
            if(isCommpressed == '|') {
                index++;
                commonPrefixLenght = Character.getNumericValue(hash.charAt(index));
                index++;
            }
            String base = startingHash.substring(0, commonPrefixLenght) + hash.substring(index, index + this.lenght - commonPrefixLenght);
            index += this.lenght - commonPrefixLenght;
            startingHash = base;
            try {
                GeoHash geoHash = GeoHash.fromGeohashString(base);
               cordinates.add(factory.getCordinate(geoHash.getOriginatingPoint().getLatitude(), geoHash.getOriginatingPoint().getLongitude()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return cordinates;
    }

}
