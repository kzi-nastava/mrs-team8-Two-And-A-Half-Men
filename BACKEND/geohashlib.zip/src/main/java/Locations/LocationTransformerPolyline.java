package Locations;

import CordinatesPacage.Cordinates;
import CordinatesPacage.CordinatesFactory;

import java.util.ArrayList;

public class LocationTransformerPolyline extends LocationTransformer {

    private int nextIndex = 0;
    private double presision;
    public LocationTransformerPolyline(CordinatesFactory factory, double presision) {
        super(factory);
        this.presision = presision;
    }

    private void encodeNumber(int num, StringBuilder encoded) {
        num = num << 1;
        if (num < 0) {
            num = ~num;
        }
        while (num >= 0x20) {
            int nextValue = (0b00100000 | (num & 0b00011111)) + 63;
            encoded.append((char) (nextValue));
            num >>= 5;
        }
        num += 63;
        encoded.append((char) (num));
    }


    @Override
    public String transformLocation(ArrayList<Cordinates> locations) {
        long lastLat = 0;
        long lastLon = 0;
        StringBuilder encoded = new StringBuilder();
        for (Cordinates location : locations) {
            long lat = Math.round(location.getLatitude() * this.presision);
            long lon = Math.round(location.getLongitude() * this.presision);
            long dLat = lat - lastLat;
            long dLon = lon - lastLon;
            encodeNumber((int) dLat, encoded);
            encodeNumber((int) dLon, encoded);
            lastLat = lat;
            lastLon = lon;
        }
        return encoded.toString();
    }

    @Override
    public ArrayList<Cordinates> transformToCordinnates(String hash) {
        ArrayList<Cordinates> locations = new ArrayList<>();
        long lat = 0;
        long lon = 0;
        int index = 0;
        while (index < hash.length()) {
            long dLat = decodeNumber(hash, index);
            index = nextIndex;
            long dLon = decodeNumber(hash, index);
            index = nextIndex;
            lat += dLat;
            lon += dLon;
            locations.add(factory.getCordinate(lat / this.presision, lon / this.presision));
        }
        return locations;
    }

    private long decodeNumber(String hash, int index) {
       long result = 0;
         int shift = 0;
         int b;
         nextIndex = index;
            do {
                b = hash.charAt(nextIndex++) - 63;
                result |= (long)(b & 0b00011111) << shift;
                shift += 5;
            } while (b >= 0b00100000);
            long delta = ((result & 1) != 0) ? ~(result >> 1) : (result >> 1);
            return delta;
    }
}