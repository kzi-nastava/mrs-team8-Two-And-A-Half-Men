import CordinatesPacage.Cordinates;
import CordinatesPacage.OpenStreatCordinatesFactory;
import Locations.LocationTransformer;
import Locations.LocationTransformerPolyline;
import Metrics.MetricsDistance;
import Metrics.MetricsTime;

import java.util.ArrayList;

class Main {

    public static void main(String [] args) {

        long startTime = System.nanoTime();
        String address = "Bulevar Cara Lazara 17 Novi sad";
        String address2 = "Posta 21000 Novi sad";
        String address3 = "Bulevar Oslobodjenja 22 Novi sad";
        ArrayList<String> adresses = new ArrayList<>();
        adresses.add(address);
        adresses.add(address2);
        adresses.add(address3);
        LocationTransformer transformer = new LocationTransformerPolyline(new OpenStreatCordinatesFactory(), 1e6);
        String hash = transformer.transformAdress(adresses);
        long endTime = System.nanoTime() - startTime;
        System.out.println(hash);
        System.out.println(endTime);
        ArrayList<Cordinates> cords = transformer.transformToCordinnates(hash);
        for (Cordinates cordinate : cords) {
            System.out.println(cordinate.getAddress());
            System.out.println("Lati: " + cordinate.getLatitude() + " Long: " + cordinate.getLongitude());
        }
        long endTime2 = System.nanoTime() - startTime - endTime;
        System.out.println(endTime2);
        System.out.println("Map distance: " + transformer.calculateDistanceMap(hash , MetricsDistance.KILOMETERS));
        long endTime21 = System.nanoTime() - startTime - endTime - endTime2;
        System.out.println(endTime21);
        System.out.println("Map time: " + transformer.calculateTimeMap(hash, MetricsTime.MINUTES));
        System.out.println("Air distance: " + transformer.calculateDistanceAir(hash));
        long endTime3 = System.nanoTime() - startTime - endTime - endTime2 - endTime21;
        System.out.println(endTime3);
        /*
        long startTimeAir = System.nanoTime();
        LocationTransformer transformer2 = new LocationWithoutCompresionTransformer(12, new OpenStreatCordinatesFactory());
        String hash2 = transformer2.transformAdress(adresses);
        long endTimeAir = System.nanoTime() - startTimeAir;
        System.out.println(hash2);
        System.out.println( endTimeAir);
        ArrayList<Cordinates> cords2 = transformer2.transformToCordinnates(hash2);
        for (Cordinates cordinate : cords2) {
            System.out.println(cordinate.getAddress());
            System.out.println("Lati: " + cordinate.getLatitude() + " Long: " + cordinate.getLongitude());
        }

        long endTime2Air = System.nanoTime() - startTimeAir - endTimeAir;
        System.out.println(endTime2Air); */ /*
        long statime = System.nanoTime();
        LocationTransformer transformer3 = new LocationTransformerWithCompresion(12, new OpenStreatCordinatesFactory());
        String hash3 = transformer3.transformAdress(adresses);
        long entime = System.nanoTime() - statime;
        System.out.println(hash3);
        System.out.println( entime);
        ArrayList<Cordinates> cords3 = transformer3.transformToCordinnates(hash3);
        for (Cordinates cordinate : cords3) {
            System.out.println(cordinate.getAddress());
            System.out.println("Lati: " + cordinate.getLatitude() + " Long: " + cordinate.getLongitude());
        }
        long endtime2 = System.nanoTime() - statime - entime;
        System.out.println(endtime2); */

    }
}